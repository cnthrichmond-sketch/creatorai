# CreatorAI — Guía de despliegue gratuito

## Archivos del proyecto
```
creatorai/
├── index.html      ← Tu landing page completa con SEO
├── sitemap.xml     ← Para que Google te indexe
├── robots.txt      ← Instrucciones para los rastreadores
├── vercel.json     ← Configuración de Vercel
└── README.md       ← Esta guía
```

---

## PASO 1 — Subir a GitHub (gratis)

1. Ve a https://github.com y crea una cuenta (si no tienes)
2. Haz clic en **"New repository"** (botón verde)
3. Ponle de nombre: `creatorai`
4. Márcalo como **Public**
5. Haz clic en **"Create repository"**
6. En la página siguiente, haz clic en **"uploading an existing file"**
7. **Arrastra los 4 archivos** (index.html, sitemap.xml, robots.txt, vercel.json)
8. Haz clic en **"Commit changes"** (botón verde abajo)

---

## PASO 2 — Desplegar en Vercel (gratis)

1. Ve a https://vercel.com y haz clic en **"Sign Up"**
2. Elige **"Continue with GitHub"** (usa la misma cuenta)
3. Haz clic en **"Add New Project"**
4. Busca tu repositorio `creatorai` y haz clic en **"Import"**
5. Deja todo por defecto y haz clic en **"Deploy"**
6. En 30 segundos tendrás una URL tipo: `creatorai.vercel.app` ✅

### Dominio personalizado (opcional, ~10€/año)
- En tu proyecto Vercel → Settings → Domains
- Añade `creatorai.app` o el dominio que compres en Namecheap/Cloudflare

---

## PASO 3 — Registrar en Google Search Console (gratis)

1. Ve a https://search.google.com/search-console
2. Haz clic en **"Añadir propiedad"**
3. Introduce tu URL: `https://creatorai.vercel.app`
4. Elige **"Etiqueta HTML"** para verificar
5. Copia el código meta que te da Google
6. Pégalo en el `<head>` de tu index.html (entre las líneas de meta tags)
7. Vuelve a subir el archivo a GitHub (Vercel se actualiza automáticamente)
8. Haz clic en **"Verificar"** en Search Console
9. Ve a **Sitemaps** → introduce `sitemap.xml` → **Enviar**

¡Listo! Google empezará a indexarte en 1-7 días.

---

## PASO 4 — Conectar el formulario de lista de espera (gratis)

Para guardar los emails del formulario, usa **Formspree**:

1. Ve a https://formspree.io y crea cuenta gratis
2. Crea un nuevo formulario → copia tu endpoint (ej: `https://formspree.io/f/xabc123`)
3. En `index.html`, busca la función `joinWaitlist` y reemplaza:

```javascript
// Reemplaza esta línea:
console.log('Email registrado:', email);

// Por esta:
await fetch('https://formspree.io/f/TU_ID_AQUI', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email })
});
```

Formspree te manda cada email directamente a tu correo. Gratis hasta 50 emails/mes.

---

## Resumen de costes

| Servicio | Coste |
|---|---|
| GitHub | Gratis |
| Vercel Hobby | Gratis |
| Google Search Console | Gratis |
| Formspree (hasta 50 leads/mes) | Gratis |
| Dominio (opcional) | ~10€/año |
| **TOTAL** | **0€** |
